<?php

$set = strtolower( basename(__FILE__, '.php') );

$$set = array(
	'brainstorming (TeamWork2) ' => $set . '_e900',
	'promoting (TeamWork2) ' => $set . '_e901',
	'communication (TeamWork2) ' => $set . '_e902',
	'team (TeamWork2) ' => $set . '_e903',
	'competition (TeamWork2) ' => $set . '_e904',
	'conference (TeamWork2) ' => $set . '_e905',
	'customer-service (TeamWork2) ' => $set . '_e906',
	'skills (TeamWork2) ' => $set . '_e907',
	'boss (TeamWork2) ' => $set . '_e908',
	'idea (TeamWork2) ' => $set . '_e909',
	'insurance (TeamWork2) ' => $set . '_e90a',
	'human-resources (TeamWork2) ' => $set . '_e90b',
	'rotation (TeamWork2) ' => $set . '_e90c',
	'exchange (TeamWork2) ' => $set . '_e90d',
	'leader (TeamWork2) ' => $set . '_e90e',
	'meeting (TeamWork2) ' => $set . '_e90f',
	'goal (TeamWork2) ' => $set . '_e910',
	'motivational-speech (TeamWork2) ' => $set . '_e911',
	'outsourcing (TeamWork2) ' => $set . '_e912',
	'partnership (TeamWork2) ' => $set . '_e913',
	'presentation (TeamWork2) ' => $set . '_e914',
	'productivity (TeamWork2) ' => $set . '_e915',
	'recruitment (TeamWork2) ' => $set . '_e916',
	'social-network (TeamWork2) ' => $set . '_e917',
	'puzzle (TeamWork2) ' => $set . '_e918',
	'productivity-1 (TeamWork2) ' => $set . '_e919',
	'structure (TeamWork2) ' => $set . '_e91a',
	'success (TeamWork2) ' => $set . '_e91b',
	'productivity-2 (TeamWork2) ' => $set . '_e91c',
	'teamwork (TeamWork2) ' => $set . '_e91d'
);