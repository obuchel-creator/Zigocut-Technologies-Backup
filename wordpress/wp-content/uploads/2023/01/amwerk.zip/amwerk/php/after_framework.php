<?php
BoldThemes_Customize_Default::$data['body_font'] = 'Assistant';
BoldThemes_Customize_Default::$data['heading_supertitle_font'] = 'Assistant';
BoldThemes_Customize_Default::$data['heading_font'] = 'Assistant';
BoldThemes_Customize_Default::$data['heading_subtitle_font'] = 'Assistant';
BoldThemes_Customize_Default::$data['menu_font'] = 'Assistant';

BoldThemes_Customize_Default::$data['accent_color'] = '#f1b209';
BoldThemes_Customize_Default::$data['alternate_color'] = '#013989';
BoldThemes_Customize_Default::$data['logo_height'] = '120';

// GENERAL
BoldThemes_Customize_Default::$data['general_elements_style'] = 'square';
BoldThemes_Customize_Default::$data['image_404'] = '';
BoldThemes_Customize_Default::$data['back_to_top'] = true;
BoldThemes_Customize_Default::$data['back_to_top_text'] = '';

// HEADING STYLE
BoldThemes_Customize_Default::$data['heading_style'] = 'default';
BoldThemes_Customize_Default::$data['show_logo_and_logo_widgets'] = false;
BoldThemes_Customize_Default::$data['page_headline_style'] = 'dark-light';

// Typography 
BoldThemes_Customize_Default::$data['button_font'] = 'Assistant';
BoldThemes_Customize_Default::$data['menu_font_size'] = '15';

// BLOG
boldthemes_remove_mb_field( 'post', 'grid_gallery' );
BoldThemes_Customize_Default::$data['grid_gallery'] = true;

// PORTFOLIO
boldthemes_remove_mb_field( 'portfolio', 'grid_gallery' );
BoldThemes_Customize_Default::$data['pf_grid_gallery'] = true;
BoldThemes_Customize_Default::$data['pf_slider_image_default'] = '';
BoldThemes_Customize_Default::$data['post_image_default'] = '';

// SIDEBAR
BoldThemes_Customize_Default::$data['sidebar_vertical_position'] = 'inside';
BoldThemes_Customize_Default::$data['sidebar_style'] = 'accentTopBorder';

require_once( get_template_directory() . '/php/after_framework/functions.php' );
require_once( get_template_directory() . '/php/after_framework/customize_params.php' );

