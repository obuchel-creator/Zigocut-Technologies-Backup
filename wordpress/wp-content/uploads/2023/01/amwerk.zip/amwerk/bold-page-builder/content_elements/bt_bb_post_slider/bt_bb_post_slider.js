(function( $ ) {
	"use strict";

})( jQuery );