<?php

	get_template_part( 'views/post/list/simple' );

?>