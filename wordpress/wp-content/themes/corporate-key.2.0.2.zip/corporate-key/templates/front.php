<?php
/**
 * Template name: Front Page
 *
 * @package Corporate_Key
 */

get_header();

get_footer();
